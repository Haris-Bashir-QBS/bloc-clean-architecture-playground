package com.example.bloc_api_integration

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
